import React from "react";
import Image from "next/image";
import Link from "next/link";

const BlogPage = () => {
  // Sample blog data
  const blogs = [
    {
      id: 1,
      title: "The Importance of Regular Car Maintenance",
      description: "Learn why keeping up with routine car maintenance can save you money and time in the long run.",
      image: "/blogs/blog1.jpg",
      link: "/blog/regular-maintenance",
    },
    {
      id: 2,
      title: "Top 5 Signs Your Car Needs Immediate Service",
      description: "Don't ignore these warning signs! Discover the top 5 indications that your car needs attention.",
      image: "/blogs/blog2.jpg",
      link: "/blog/signs-service",
    },
    {
      id: 3,
      title: "How to Choose the Right Mechanic for Your Car",
      description: "Find out the essential tips for selecting a trustworthy and skilled mechanic.",
      image: "/blogs/blog3.jpg",
      link: "/blog/choose-mechanic",
    },
    {
      id: 4,
      title: "DIY Car Maintenance Tips for Beginners",
      description: "Start your car maintenance journey with these simple and effective DIY tips.",
      image: "/blogs/blog4.jpg",
      link: "/blog/diy-tips",
    },
    {
      id: 5,
      title: "The Evolution of Electric Vehicles",
      description: "Explore the journey of electric vehicles and their impact on the automotive industry.",
      image: "/blogs/blog5.jpg",
      link: "/blog/electric-vehicles",
    },
    {
      id: 6,
      title: "Understanding Engine Warning Lights",
      description: "Decode those mysterious engine warning lights and learn what they mean.",
      image: "/blogs/blog6.jpg",
      link: "/blog/engine-warning-lights",
    },
    {
      id: 7,
      title: "Benefits of Using Synthetic Oil for Your Car",
      description: "Is synthetic oil worth it? Learn the advantages it offers over conventional oil.",
      image: "/blogs/blog7.jpg",
      link: "/blog/synthetic-oil-benefits",
    },
    {
      id: 8,
      title: "Essential Tips for Driving in Harsh Weather",
      description: "Stay safe on the road with these essential tips for driving in extreme weather conditions.",
      image: "/blogs/blog8.jpg",
      link: "/blog/harsh-weather-driving",
    },
  ];

  return (
    <div className="container mx-auto py-6">
      {/* Blog Page Header */}
      <h2 className="text-3xl font-bold">Blog Page</h2>
      <p className="mt-4">Explore our latest blogs for helpful insights and tips!</p>

      {/* Blog Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-8">
        {blogs.map((blog) => (
          <div key={blog.id} className="bg-white shadow-lg rounded-lg overflow-hidden">
            <Image
              src={blog.image}
              alt={blog.title}
              width={400}
              height={250}
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h3 className="text-xl font-bold mb-2">{blog.title}</h3>
              <p className="text-gray-600 mb-4">{blog.description}</p>
              <Link
                href={blog.link}
                className="text-blue-500 font-bold hover:underline"
              >
                Read More
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BlogPage;
