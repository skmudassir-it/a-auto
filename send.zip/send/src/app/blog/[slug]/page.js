import React from "react";
import { notFound } from "next/navigation";
import Image from "next/image";

const blogData = {
    "regular-maintenance": {
      title: "The Importance of Regular Car Maintenance",
      image: "/blogs/blog1.jpg",
      content: `
        Regular car maintenance is crucial for the longevity and performance of your vehicle. 
        It helps prevent costly repairs, ensures safety, and maintains the resale value of your car.
        
        Here are some tips for regular maintenance:
        - Check and change the engine oil regularly.
        - Keep an eye on tire pressure and tread wear.
        - Replace air filters and spark plugs as needed.
        - Schedule regular brake inspections.
        
        By following these steps, you can save money in the long run and enjoy a smoother driving experience.
      `,
    },
    "signs-service": {
      title: "Top 5 Signs Your Car Needs Immediate Service",
      image: "/blogs/blog2.jpg",
      content: `
        Ignoring the warning signs of car issues can lead to costly repairs. 
        Watch out for these top 5 signs that indicate your car needs immediate service:
        1. Unusual noises from the engine or brakes.
        2. A check engine light that stays on.
        3. Smoke coming from the exhaust or engine bay.
        4. Unresponsive steering or braking.
        5. Fluid leaks under your car.
      `,
    },
    "choose-mechanic": {
      title: "How to Choose the Right Mechanic for Your Car",
      image: "/blogs/blog3.jpg",
      content: `
        Selecting the right mechanic can make a significant difference in your car's performance and longevity. 
        Here’s how to choose a trustworthy mechanic:
        - Look for certifications like ASE (Automotive Service Excellence).
        - Read online reviews and ask for recommendations.
        - Visit the garage and observe their tools and cleanliness.
        - Compare prices but don't compromise on quality.
        
        A good mechanic will communicate clearly and prioritize your safety.
      `,
    },
    "diy-tips": {
      title: "DIY Car Maintenance Tips for Beginners",
      image: "/blogs/blog4.jpg",
      content: `
        Maintaining your car doesn't have to be daunting. Here are some DIY tips for beginners:
        - Regularly check and top up fluids like engine oil, coolant, and brake fluid.
        - Replace wiper blades and air filters when necessary.
        - Monitor tire pressure and inspect for wear and tear.
        - Learn how to replace a flat tire with a spare.
        
        Start small, and over time, you’ll build confidence in handling basic car maintenance.
      `,
    },
    "electric-vehicles": {
      title: "The Evolution of Electric Vehicles",
      image: "/blogs/blog5.jpg",
      content: `
        Electric vehicles (EVs) have come a long way, from being a niche product to becoming a global phenomenon. 
        Here’s a brief look at their evolution:
        - Early electric cars in the 19th century were overshadowed by internal combustion engines.
        - Advances in battery technology in the late 20th century reignited interest in EVs.
        - Modern EVs like Tesla and Nissan Leaf offer impressive range and performance.
        - Governments worldwide are pushing for EV adoption to combat climate change.
        
        The future of transportation is undoubtedly electric.
      `,
    },
    "engine-warning-lights": {
      title: "Understanding Engine Warning Lights",
      image: "/blogs/blog6.jpg",
      content: `
        Engine warning lights can be intimidating, but understanding them can help you take appropriate action:
        - **Check Engine Light**: May indicate issues with the engine or emissions system.
        - **Oil Pressure Warning**: Low oil levels or oil pump failure.
        - **Battery Alert**: Battery or alternator problems.
        - **Brake System Warning**: Low brake fluid or brake system failure.
        
        Don’t ignore warning lights. Consult a mechanic if the issue persists.
      `,
    },
    "synthetic-oil-benefits": {
      title: "Benefits of Using Synthetic Oil for Your Car",
      image: "/blogs/blog7.jpg",
      content: `
        Synthetic oil offers numerous advantages over conventional oil, making it worth considering:
        - **Enhanced Engine Protection**: Better lubrication reduces wear and tear.
        - **Improved Performance in Extreme Temperatures**: Works efficiently in both hot and cold climates.
        - **Longer Oil Change Intervals**: Synthetic oil lasts longer, reducing maintenance frequency.
        - **Cleaner Engine**: Prevents sludge buildup for smoother engine performance.
        
        Although more expensive, synthetic oil provides better value in the long run.
      `,
    },
    "harsh-weather-driving": {
      title: "Essential Tips for Driving in Harsh Weather",
      image: "/blogs/blog8.jpg",
      content: `
        Driving in extreme weather conditions can be challenging. Stay safe with these tips:
        - **Rain**: Ensure good wiper blades and reduce speed on wet roads.
        - **Snow/Ice**: Use winter tires and maintain a safe following distance.
        - **Fog**: Turn on fog lights and avoid high beams.
        - **Heat**: Check coolant levels and tire pressure to prevent overheating.
        
        Always prioritize safety and adjust your driving to match the conditions.
      `,
    },
  };
  

  const BlogDetail = ({ params }) => {
    const { slug } = params;
  
    const blog = blogData[slug];
  
    if (!blog) {
      notFound(); // Renders 404 page
    }
  
    return (
      <div className="container mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-4">{blog.title}</h1>
        <Image
          src={blog.image}
          alt={blog.title}
          width={800}
          height={400}
          className="rounded-lg mb-6"
        />
        <p className="text-lg leading-relaxed whitespace-pre-line">{blog.content}</p>
      </div>
    );
  };
  

export default BlogDetail;
