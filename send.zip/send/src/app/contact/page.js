import React from "react";

const Contact = () => {
  return (
    <div className="container mx-auto py-6 px-4">
      <h2 className="text-3xl font-bold mb-6 text-center">Contact Us</h2>
      <div className="flex flex-col md:flex-row gap-8">
        {/* Column 1: Map */}
        <div className="w-full md:w-3/5">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3311.2103012132653!2d-89.86583708498093!3d35.16242858031901!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x887f8581bdf8e217%3A0xe2e3d7f14200e2d7!2s5200%20Elmore%20Rd%2C%20Memphis%2C%20TN%2038134%2C%20USA!5e0!3m2!1sen!2sus!4v1686789871234!5m2!1sen!2sus"
            width="100%"
            height="400"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            title="Google Map to 5200 Elmore Rd"
            className="rounded-lg"
          ></iframe>
        </div>

        {/* Column 2: Contact Info */}
        <div className="w-full md:w-1/4 flex flex-col gap-6">
          {/* Row 1: Contact Form */}
          <div className="bg-white shadow-lg rounded-lg p-6">
            <h3 className="text-xl font-bold mb-4">Send Us a Message</h3>
            <form>
              <div className="mb-4">
                <label
                  htmlFor="name"
                  className="block text-gray-700 font-medium mb-2"
                >
                  Name
                </label>
                <input
                  type="text"
                  id="name"
                  placeholder="Your Name"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="mb-4">
                <label
                  htmlFor="email"
                  className="block text-gray-700 font-medium mb-2"
                >
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  placeholder="Your Email"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="mb-4">
                <label
                  htmlFor="message"
                  className="block text-gray-700 font-medium mb-2"
                >
                  Message
                </label>
                <textarea
                  id="message"
                  rows="4"
                  placeholder="Your Message"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full py-2 bg-blue-500 text-white font-bold rounded-lg hover:bg-blue-600 transition"
              >
                Send Message
              </button>
            </form>
          </div>

          {/* Row 2: Phone Number */}
          <div className="bg-white shadow-lg rounded-lg p-6">
            <h3 className="text-xl font-bold mb-4">Phone</h3>
            <p>
              <a
                href="tel:(901) 387-2390"
                className="text-blue-500 font-medium hover:underline"
              >
                (901) 387-2390
              </a>
            </p>
          </div>

          {/* Row 3: Address */}
          <div className="bg-white shadow-lg rounded-lg p-6">
            <h3 className="text-xl font-bold mb-4">Address</h3>
            <p className="text-gray-700">5200 Elmore Rd, Memphis, TN 38134</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
