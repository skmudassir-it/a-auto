import React from "react";

const Electricals = () => {
  return (
    <div className="container mx-auto py-6">
      <h2 className="text-3xl font-bold">Electricals Page</h2>
      <p className="mt-4">This is the Electricals Page of our responsive React app.</p>
    </div>
  );
};

export default Electricals;
