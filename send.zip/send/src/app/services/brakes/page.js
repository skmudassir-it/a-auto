import React from "react";

const Brakes = () => {
  return (
    <div className="container mx-auto py-6">
      <h2 className="text-3xl font-bold">Brakes Page</h2>
      <p className="mt-4">This is the Brakes Page of our responsive React app.</p>
    </div>
  );
};

export default Brakes;
