import Link from 'next/link';
import Image from 'next/image';

const Footer = () => {
  return (
    <footer className="bg-blue-600 text-white p-8">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Section 1: Name */}
        <div>
        <Image src="/Logo.png" alt="Auto Service Logo" width={150} height={50} />          <p>Your trusted partner for all auto repair needs.</p>
        </div>

        {/* Section 2: Navigation */}
        <div>
          <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
          <ul className="space-y-2">
            <li><Link href="/" className="hover:text-blue-300">Home</Link></li>
            <li><Link href="/blog" className="hover:text-blue-300">Blog</Link></li>
            <li><Link href="/contact" className="hover:text-blue-300">Contact</Link></li>
          </ul>
        </div>

        {/* Section 3: Contact Details */}
        <div>
          <h3 className="text-xl font-semibold mb-4">Contact Us</h3>
          <p className="mb-2">Email: info@autoservice.com</p>
          <p>
            Phone: <a href="tel:(901) 387-2390" className="hover:text-blue-300">(901) 387-2390</a>
          </p>
        </div>

        {/* Section 4: Address */}
        <div>
          <h3 className="text-xl font-semibold mb-4">Our Location</h3>
          <a 
            href="https://www.google.com/maps/search/?api=1&query=3265+Elvis+Presley+Blvd,+Memphis,+TN+38116" 
            target="_blank" 
            rel="noopener noreferrer"
            className="hover:text-blue-300"
          >
            5200 Elmore Rd <br />
            Memphis, TN 38134
          </a>
        </div>
      </div>
      <div className="mt-8 text-center">
        <p>&copy; 2025 A+ Automotive Service. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
